<?php
// To call this page, in the browser type:
// http://localhost/user/1

echo "USER IN VIEWS WITH ID: $id";