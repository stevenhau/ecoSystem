<?php
// To call this page, in the browser type:
// http://localhost/user/A/B

echo "USER IN VIEWS: $name $last_name";