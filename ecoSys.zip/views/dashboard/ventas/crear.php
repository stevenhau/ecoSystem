<?php include('../layouts/header.php'); 

?>

<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Agregar Nuevo Venta</h1>
        <div class="card mb-4">

            <div class="card-body">
                <form action="guardar.php" method="POST">
                    <input type="hidden" >
                    <div class="form-floating mb-3">
                        <input class="form-control" name="etapa" value="1" type="text" />
                        <label>Etapa</label>
                    </div>
                    <div class="form-floating mb-3">
                        <select class="form-control" name="lote">
                            <?php
                                for($i=1;$i<=24;$i++){
                                    echo '<option value="'.$i.'">'.$i.'</option>';
                                }?>
                        </select>
                    </div>
                    <div class="form-floating mb-3">
                        <input class="form-control" type="text">
                        <label>Nombre del Cliente</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input class="form-control" type="text" value="0">
                        <label>Enganche</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input class="form-control" type="text" value="120">
                        <label>Numero de Meses</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input class="form-control" type="date">
                        <label>Fecha de Compra</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input class="form-control" type="text">
                        <label>Asesor</label>
                    </div>
                    <div class="mt-4 mb-0">
                        <div class="d-grid"><a class="btn btn-primary btn-block" href="login.html">Guardar</a></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<?php include('../layouts/footer.php'); ?>