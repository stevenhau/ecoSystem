<?php include('../layouts/header.php');

$id = $_GET['id'];

$comando = $con->prepare("SELECT * FROM lotes WHERE id_desarrollo = $id");
$comando->execute();
$resultados = $comando->fetchAll(PDO::FETCH_ASSOC);

?>
<style>
    .disponible{
        background-color: #fff;
    }
    .vendido{
        background-color: #FFA420;
    }
    .apartado{
        background-color: #ffff00;
    }
    .otro{
        background-color: #90CAF9;
    }
</style>

<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Lsta de Pagos <?= $id == 1 ? " EL CEDRAL ECO HABITAT I" : " EL CEDRAL ECO HABITAT II"; ?></h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Etapas
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>Lote</th>
                            <th><?= $id == 1 ? "Etapa" : "Manzana"; ?></th>
                            <th>MEDIDA/M2</th>
                            <th>COSTO TOTAL</th>
                            <th>ENGANCHE</th>
                            <th>NO. DE MENSUALIDADES</th>
                            <th>PAGO NUMERO</th>
                            <th>MENSUALIDAD</th>
                            <th>INTERES 5%</th>
                            <th>PAGO TOTAL MENSUAL</th>
                            <th>FECHA DE COMPRA</th>
                            <th>PRIMER MENSUALIDAD</th>
                            <th>DIAS DE PAGO</th>
                            <th>NOMBRE</th>
                            <th>MTTO.</th>
                            <th>Estatus</th>
                            <th>Pagar Mensualidad</th>
                            <th>Pago a Capital</th>
                            <th>Desacaragar Comprobante</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($resultados as $resultado) { ?>
                            <tr class="<?php if($resultado["estatus"] == 1){ echo "disponible";}if($resultado["estatus"] == 2){echo "vendido";}if($resultado["estatus"] == 3){echo "apartado";} if($resultado["estatus"] == 4 ){ echo "otro";}?>">
                                <td>L-<?= $resultado["numero_lote"];?></td>
                                <td><?= $id == 1 ? "E-" : "MZ-"; ?><?= $resultado["id_etapa"]; ?></td>
                                <td><?= $resultado["medida"]; ?></td>
                                <td>$<?= number_format(intval($resultado["costo"]), 2); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><?= $resultado["nombre_cliente"]; ?></td>
                                <td>$<?= number_format(intval($resultado["mantenimiento"]), 2); ?></td>
                                <td style="text-transform: uppercase;"><?php if($resultado["estatus"] == 1){ echo "disponible";}if($resultado["estatus"] == 2){echo "vendido";}if($resultado["estatus"] == 3){echo "apartado";}if($resultado["estatus"] == 4){echo "Casa Club";}?></td>
                                <td>
                                    <a class="btn btn-success btn-block" href="#">Pagar Mensualidad</a>
                                </td>
                                <td>
                                    <a class="btn btn-info btn-block" href="#">Pago a Capital</a>
                                </td>
                                <td>
                                    <a class="btn btn-primary btn-block" href="#">Desacaragar Comprobante</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php include('../layouts/footer.php'); ?>