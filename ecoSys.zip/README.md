# PHP ROUTER

Secure router with XSS and CSRF

1. Download the file ".htaccess" and place it under the root directory (html, htdocs, or www) of your web server

2. Download the file "router.php" and place it under the root directory (html, htdocs, or www) of your web server

3. Download the file "routes.php" and place it under the root directory (html, htdocs, or www) of your web server

In the browser go to "localhost" or "127.0.0.1" and you should see the word "Index" displayed in the website.

Feel free to delete all the routes in the "routes.php" file and create your own. Most likely you want to keep the last route for "Page not found".

For details about routing, visit https://phprouter.com
